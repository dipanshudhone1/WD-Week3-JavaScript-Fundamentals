// Task 5: Loops
console.log("Numbers 1 to 10:");
for (let i = 1; i <= 10; i++) console.log(i);
console.log("Even numbers 2 to 20:");
for (let i = 2; i <= 20; i += 2) console.log(i);
console.log("Odd numbers 1 to 19:");
for (let i = 1; i < 20; i += 2) console.log(i);
const tableNumber = 7;
console.log("Multiplication table of " + tableNumber + ":");
for (let i = 1; i <= 10; i++) console.log(tableNumber + " x " + i + " = " + (tableNumber * i));
let sum = 0, count = 1;
while (count <= 10) { sum += count; count++; }
console.log("Sum from 1 to 10:", sum);
let reverse = 5;
do { console.log("Reverse:", reverse); reverse--; } while (reverse >= 1);
