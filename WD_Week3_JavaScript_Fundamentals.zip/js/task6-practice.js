// Task 6: Five JavaScript Practice Programs
// Program 1: Total and average of three marks
const mark1 = 78, mark2 = 84, mark3 = 91;
const marksTotal = mark1 + mark2 + mark3;
const average = marksTotal / 3;
console.log("Practice 1 - Total:", marksTotal, "Average:", average.toFixed(2));
// Program 2: Leap year check
const year = 2024;
if ((year % 4 === 0 && year % 100 !== 0) || year % 400 === 0) console.log("Practice 2 -", year, "is a leap year.");
else console.log("Practice 2 -", year, "is not a leap year.");
// Program 3: Factorial using a loop
const factorialNumber = 5;
let factorial = 1;
for (let i = 1; i <= factorialNumber; i++) factorial *= i;
console.log("Practice 3 - Factorial of", factorialNumber, "is", factorial);
// Program 4: Countdown with even/odd labels
console.log("Practice 4 - Countdown with parity:");
for (let i = 10; i >= 1; i--) console.log(i, i % 2 === 0 ? "even" : "odd");
// Program 5: Largest of four numbers
const n1 = 16, n2 = 42, n3 = 9, n4 = 27;
let largest = n1;
if (n2 > largest) largest = n2;
if (n3 > largest) largest = n3;
if (n4 > largest) largest = n4;
console.log("Practice 5 - Largest number:", largest);
