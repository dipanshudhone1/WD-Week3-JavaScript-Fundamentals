// Task 2: Variables & Data Types
let studentName = "Aarav";       // String
let studentAge = 18;             // Number
let isLearningJavaScript = true; // Boolean
let notAssigned;                 // undefined
let emptyValue = null;           // null
console.log("Name:", studentName, "| typeof:", typeof studentName);
console.log("Age:", studentAge, "| typeof:", typeof studentAge);
console.log("Learning JavaScript:", isLearningJavaScript, "| typeof:", typeof isLearningJavaScript);
console.log("Not assigned:", notAssigned, "| typeof:", typeof notAssigned);
console.log("Empty value:", emptyValue, "| typeof:", typeof emptyValue); // typeof null is "object" in JavaScript
let score;
score = 95; // Assignment after declaration
console.log("Assigned score:", score);
const language = "JavaScript";
console.log("Constant language:", language);
// A const variable must be initialized when declared and cannot be reassigned.
