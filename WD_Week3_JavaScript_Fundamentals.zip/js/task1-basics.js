// Task 1: JavaScript Basics
// Single-line comments begin with two slashes.
/*
  This is a multi-line comment.
  JavaScript statements are commonly separated by semicolons.
*/
console.log("Hello, JavaScript!");
console.log("This is Task 1: JavaScript Basics.");
let learnerName = "Student"; // Variable declaration and assignment
console.log("Welcome, " + learnerName + "!");
const courseName = "Web Development";
console.log("Course: " + courseName);
// Open index.html and check the browser console to see these messages.
