// Task 4: Conditional Statements
const numberToCheck = -7;
if (numberToCheck > 0) {
  console.log(numberToCheck + " is positive.");
} else if (numberToCheck < 0) {
  console.log(numberToCheck + " is negative.");
} else {
  console.log("The number is zero.");
}
const evenOddNumber = 14;
if (evenOddNumber % 2 === 0) {
  console.log(evenOddNumber + " is even.");
} else {
  console.log(evenOddNumber + " is odd.");
}
const age = 18;
if (age >= 18) {
  console.log("Age check: eligible (18 or older).");
} else {
  console.log("Age check: not eligible yet.");
}
// Nested if example
const nestedNumber = 15;
if (nestedNumber > 0) {
  if (nestedNumber > 10) console.log("Nested if: positive and greater than 10.");
  else console.log("Nested if: positive but not greater than 10.");
} else console.log("Nested if: number is not positive.");
// Greatest of three numbers
const first = 22, second = 17, third = 31;
if (first >= second && first >= third) console.log("Greatest number:", first);
else if (second >= first && second >= third) console.log("Greatest number:", second);
else console.log("Greatest number:", third);
// Grade based on marks
const marks = 86;
if (marks >= 90) console.log("Grade: A");
else if (marks >= 80) console.log("Grade: B");
else if (marks >= 70) console.log("Grade: C");
else if (marks >= 60) console.log("Grade: D");
else console.log("Grade: F");
