// Task 3: Operators
const a = 12;
const b = 5;
// Arithmetic operators
console.log("Addition:", a + b);
console.log("Subtraction:", a - b);
console.log("Multiplication:", a * b);
console.log("Division:", a / b);
console.log("Remainder:", a % b);
console.log("Exponent:", a ** 2);
// Assignment operators
let total = 10;
total += 4;
console.log("After += 4:", total);
total *= 2;
console.log("After *= 2:", total);
// Comparison operators
console.log("a > b:", a > b);
console.log("a === b:", a === b);
console.log("a !== b:", a !== b);
// Logical operators
console.log("Both conditions true:", a > 10 && b < 10);
console.log("At least one condition true:", a < 10 || b < 10);
console.log("Negation of true:", !true);
// Increment and decrement
let counter = 3;
counter++;
console.log("After increment:", counter);
counter--;
console.log("After decrement:", counter);
