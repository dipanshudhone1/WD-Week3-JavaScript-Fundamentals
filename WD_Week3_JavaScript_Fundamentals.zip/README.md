# WD Week 3 – JavaScript Fundamentals (Part 1) 🚀

## About
This project is my Week 3 Web Development assignment. It demonstrates JavaScript syntax, variables and data types, operators, conditional statements, loops, and five combined practice programs.

## Topics Covered
- JavaScript syntax, comments, statements, and `console.log()`
- `let`, `const`, variable declaration and assignment
- String, Number, Boolean, `undefined`, and `null`; checking values with `typeof`
- Arithmetic, assignment, comparison, and logical operators
- Increment and decrement operators
- `if`, `if...else`, `else if`, and nested `if`
- `for`, `while`, and `do...while` loops
- Five practice programs using the concepts above

## Project Structure
```text
WD_Week3_JavaScript_Fundamentals/
├── index.html
├── style.css
├── README.md
└── js/
    ├── task1-basics.js
    ├── task2-variables.js
    ├── task3-operators.js
    ├── task4-conditionals.js
    ├── task5-loops.js
    └── task6-practice.js
```

## How to Run
1. Download or clone this repository.
2. Open `index.html` in a web browser.
3. Open Developer Tools → Console (usually F12 or Ctrl+Shift+J) to view program output.
4. Each task is kept in a separate JavaScript file for easy review.

## Note
The assignment intentionally avoids DOM manipulation and event handling, as requested.

Created as part of my Web Development learning journey.
